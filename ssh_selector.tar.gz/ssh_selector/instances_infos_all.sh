declare -A connection=( 
["ebeta-Web-1"]="ssh -i /data/ssh_key/AWS.pem ubuntu@10.0.156.84" 
["alpha-web-1"]="ssh -i /data/ssh_key/us1_AWS.pem ubuntu@172.31.5.212" 
["alpha-Web-1"]="ssh -i /data/ssh_key/AWS.pem ubuntu@10.0.159.154" 
["prod-Dev-1"]="ssh -i /data/ssh_key/AWS.pem ubuntu@10.0.28.2" 
["prod-Dev-NAT"]="ssh -i /data/ssh_key/AWS.pem ubuntu@52.10.12.234" 
)

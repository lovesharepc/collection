# from tabnanny import verbose

import boto3
import pprint

# import sys

# import io
# import re


def update_inventory():
    # zyxel
    # aws_infos=[{"region": "ap-northeast-1",
    #             "profile": "alpha3_ci"},
    #             {"region": "eu-west-1",
    #             "profile": "prod3_ci"},]
    # my lab            
    aws_infos=[{"region": "us-west-1",
                "profile": "owan_lab"},
                {"region": "us-west-2",
                "profile": "owan_lab"},]

    instances_infos=[{"instance_region": "",
               "instance_ip": "",
               "instance_name": "",
               "instance_key": "", 
               "instance_pub_ip": "",}]
    instances_infos.pop(0) # pop sample

    for aws_info in aws_infos:
        session = boto3.Session(
            region_name=aws_info["region"],
            profile_name=aws_info["profile"],

        )
        client = session.client('ec2')
        ret=client.describe_instances()

        # pp = pprint.PrettyPrinter(depth=10)
        # pp.pprint(ret)

        for l in ret["Reservations"]:
            for instances_info in l["Instances"]:

                tags={}
                # convert to dictionary
                for tag in instances_info["Tags"]:
                    tags.update({tag["Key"]: tag["Value"]})
                
                if tags.get("Name")== None:
                    tags["Name"] = instances_info["PrivateIpAddress"]


                instances_infos.append({"instance_region": aws_info["region"],
                                        "instance_ip": instances_info["PrivateIpAddress"],
                                        "instance_pub_ip": instances_info.get("PublicIpAddress"),
                                        # if name exist, use name
                                        "instance_name": tags.get("Name"), 
                                        "instance_key": instances_info["KeyName"],})


    # zyxel
    sites={"prod-Web": [],
           "prod-DevConn": [],
           "ebeta-Web": [],
           "ebeta-DevConn": [],
           "alpha-NebulaWeb": [],
           "other": [],}
           
    # my lab
    # sites={"prod": [],
    #        "ebeta": [],
    #        "alpha": [],
    #        "other": [],}

    # # sites_list not include other
    # sites_list=""
    # for site in sites:
    #     if site == "other":
    #         break
    #     sites_list=sites_list + " " + site




    for instance in instances_infos:
        for site in sites:
            if instance["instance_name"].startswith(site):
                if instance["instance_name"].find("NAT") != -1:
                    instance["instance_ip"]=instance["instance_pub_ip"]
                sites[site].append({"instance_region": instance["instance_region"],
                                        "instance_ip": instance["instance_ip"],
                                        "instance_name": instance["instance_name"],
                                        "instance_key": instance["instance_key"],})
                
                # continue
                break
            elif site == "other":
                if instance["instance_name"].find("NAT") != -1:
                    instance["instance_ip"]=instance["instance_pub_ip"]
                sites["other"].append({"instance_region": instance["instance_region"],
                                        "instance_ip": instance["instance_ip"],
                                        "instance_name": instance["instance_name"],
                                        "instance_key": instance["instance_key"],})

    # pp = pprint.PrettyPrinter(depth=10)
    # pp.pprint(sites)


    f=open("instances_infos.sh","w")
    f.truncate()
    f_all=open("instances_infos_all.sh","w")
    f_all.truncate()
    f_all.write("declare -A connection=( \n")
    for site in sites:
        site_o=site.replace("-","_")
        f.write(f"{site_o}=(")
        x=0
        for instance in sites[site]:
            instance_name=instance["instance_name"]
            instance_ip=instance["instance_ip"]
            instance_key=instance["instance_key"]
            f.write(f"{x} {instance_name}\n")
            f_all.write(f"[\"{instance_name}\"]=\"ssh -i /data/ssh_key/{instance_key}.pem ubuntu@{instance_ip}\" \n")

            x=x+1
        f.write(")\n")
    f_all.write(")\n")
    f.close()
    f_all.close()
    
update_inventory()
# convert_instances_infos()
# if "update" == sys.argv[1]:
#     update_inventory()
# else:
#     convert_instances_infos()

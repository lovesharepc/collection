#!/bin/bash
set -x
HEIGHT=45
WIDTH=60
CHOICE_HEIGHT=45
BACKTITLE="ssh connector"
TITLE="ssh connector"
MENU="Choose one of the following options:"

source instances_infos.sh
source instances_infos_all.sh


case $1 in
    pw)
        CHOICE=$(dialog --clear \
                        --backtitle "$BACKTITLE" \
                        --title "$TITLE" \
                        --menu "$MENU" \
                        $HEIGHT $WIDTH $CHOICE_HEIGHT \
                        "${prod_Web[@]}" \
                        2>&1 >/dev/tty)
        eval "${connection[${prod_Web[$CHOICE*2+1]}]} "
        ;;
    pd)
        CHOICE=$(dialog --clear \
                        --backtitle "$BACKTITLE" \
                        --title "$TITLE" \
                        --menu "$MENU" \
                        $HEIGHT $WIDTH $CHOICE_HEIGHT \
                        "${prod_DevConn[@]}" \
                        2>&1 >/dev/tty)
        eval "${connection[${prod_DevConn[$CHOICE*2+1]}]} "
        ;;
    ew)
        CHOICE=$(dialog --clear \
                        --backtitle "$BACKTITLE" \
                        --title "$TITLE" \
                        --menu "$MENU" \
                        $HEIGHT $WIDTH $CHOICE_HEIGHT \
                        "${ebeta_Web[@]}" \
                        2>&1 >/dev/tty)
        eval "${connection[${ebeta_Web[$CHOICE*2+1]}]} "
        ;;
    ed)
        CHOICE=$(dialog --clear \
                        --backtitle "$BACKTITLE" \
                        --title "$TITLE" \
                        --menu "$MENU" \
                        $HEIGHT $WIDTH $CHOICE_HEIGHT \
                        "${ebeta_DevConn[@]}" \
                        2>&1 >/dev/tty)
        eval "${connection[${ebeta_DevConn[$CHOICE*2+1]}]} "
        ;;
    gw)
        CHOICE=$(dialog --clear \
                        --backtitle "$BACKTITLE" \
                        --title "$TITLE" \
                        --menu "$MENU" \
                        $HEIGHT $WIDTH $CHOICE_HEIGHT \
                        "${alpha_NebulaWeb[@]}" \
                        2>&1 >/dev/tty)
        eval "${connection[${alpha_NebulaWeb[$CHOICE*2+1]}]} "
        ;;
    o)
        CHOICE=$(dialog --clear \
                        --backtitle "$BACKTITLE" \
                        --title "$TITLE" \
                        --menu "$MENU" \
                        $HEIGHT $WIDTH $CHOICE_HEIGHT \
                        "${other[@]}" \
                        2>&1 >/dev/tty)
        eval "${connection[${other[$CHOICE*2+1]}]} "
        ;;
esac
